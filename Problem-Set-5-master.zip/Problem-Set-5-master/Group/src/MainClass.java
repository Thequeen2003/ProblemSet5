/**********************************************************************
 * @file RandomWalk.java
 * @brief: Sometimes "Game over" does not appear
 * @author Maahla Fofack, Murren Kelly, Alantis Green
 * @date: 11/30/2022
 * @acknowledgement: Krohn Education How to Code Pong Game Video
 ***********************************************************************/

import javax.swing.*;
import java.awt.*;

public class MainClass {
    public static int level;
    public static void main(String[] args) {
        Menu menu = new Menu();

    }

}
